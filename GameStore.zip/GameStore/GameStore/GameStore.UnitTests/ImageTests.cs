﻿using GameStore.Domain.Abstract;
using GameStore.Domain.Entities;
using GameStore.WebUI.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace GameStore.UnitTests
{
    [TestClass]
    public class ImageTests
    {
        private readonly Mock<IGameRepository> gameRepoMock = new Mock<IGameRepository>();
        private readonly GameController controller;

        public ImageTests()
        {
            gameRepoMock.Setup(m => m.Games).Returns(new List<Game>
            {
                new Game { GameId = 1 , Name = "Game1" },
                new Game { GameId = 2 , Name = "Game2" },
                new Game { GameId = 3 , Name = "Game3", ImageData = new byte[] { }, ImageMimeType = "image/png" },
            }.AsQueryable());
            controller = new GameController(gameRepoMock.Object);
        }

        [TestMethod]
        public void Can_Retrieve_Image_Data()
        {
            // Action
            ActionResult result = controller.GetImage(3);

            // Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(FileResult));
            Assert.AreEqual("image/png", (result as FileResult).ContentType);
        }

        [TestMethod]
        public void Cannot_Retrieve_Image_Data_For_Invalid_Id()
        {
            // Action
            ActionResult result = controller.GetImage(int.MaxValue);

            // Assert
            Assert.IsNull(result);
        }
    }
}
