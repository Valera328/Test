﻿using GameStore.WebUI.Controllers;
using GameStore.WebUI.Infrastructure.Abstract;
using GameStore.WebUI.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Mvc;

namespace GameStore.UnitTests
{
    /// <summary>
    /// Summary description for AdminSecurityTests
    /// </summary>
    [TestClass]
    public class AdminSecurityTests
    {
        private readonly Mock<IAuthProvider> authProviderMock = new Mock<IAuthProvider>();
        private readonly AccountController controller;

        public AdminSecurityTests()
        {
            authProviderMock.Setup(m => m.Authenticate("admin", "admin")).Returns(true);
            controller = new AccountController(authProviderMock.Object);
        }

        [TestMethod]
        public void Can_Login_With_Valid_Credentials()
        {
            // Arrange
            LoginViewModel model = new LoginViewModel
            {
                UserName = "admin",
                Password = "admin"
            };

            // Action
            ActionResult result = controller.Login(model, "/MyURL");

            // Assert
            Assert.IsInstanceOfType(result, typeof(RedirectResult));
            Assert.AreEqual("/MyURL", (result as RedirectResult).Url);
        }

        [TestMethod]
        public void Cannot_Login_With_Invalid_Credentials()
        {
            // Arrange
            LoginViewModel model = new LoginViewModel
            {
                UserName = "bad",
                Password = "bad"
            };

            // Action
            ActionResult result = controller.Login(model, "/MyURL");

            // Assert
            Assert.IsInstanceOfType(result, typeof(ViewResult));
            Assert.IsFalse((result as ViewResult).ViewData.ModelState.IsValid);
        }
    }
}
