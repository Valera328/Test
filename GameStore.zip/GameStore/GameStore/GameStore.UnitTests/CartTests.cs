﻿using GameStore.Domain.Abstract;
using GameStore.Domain.Entities;
using GameStore.WebUI.Controllers;
using GameStore.WebUI.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace GameStore.UnitTests
{
    [TestClass]
    public class CartTests
    {
        private readonly Cart cart = new Cart();
        private readonly List<Game> gamesList;
        private readonly Mock<IGameRepository> gameRepoMock = new Mock<IGameRepository>();
        private readonly Mock<IOrderProcessor> orderProcMock = new Mock<IOrderProcessor>();

        public CartTests()
        {
            // Arrange
            gamesList = new List<Game>
            {
                new Game { GameId = 1, Name = "Game1", Price = 100 },
                new Game { GameId = 2, Name = "Game2", Price = 55 }
            };

            cart.AddItem(gamesList[0], 1);
            cart.AddItem(gamesList[1], 1);

            gameRepoMock.Setup(m => m.Games).Returns(new List<Game>
            {
                new Game {GameId = 3, Name = "Game3", Category = "Cat3"}
            }.AsQueryable());
        }

        /// <summary>
        /// Проверяем возможность добавления новых записей в корзину
        /// </summary>
        [TestMethod]
        public void Can_Add_New_Lines()
        {
            // Action
            List<CartLine> results = cart.Lines.ToList();

            // Assert
            Assert.AreEqual(2, results.Count);
            Assert.AreEqual(gamesList[0], results[0].Game);
            Assert.AreEqual(gamesList[1], results[1].Game);
        }

        /// <summary>
        /// Проверяем возможность увеличения количества покупаемого товара
        /// </summary>
        [TestMethod]
        public void Can_Add_Quantity_For_Existing_Lines()
        {
            // Action
            cart.AddItem(gamesList[0], 5);
            List<CartLine> results = cart.Lines.OrderBy(c => c.Game.GameId).ToList();

            // Assert
            Assert.AreEqual(2, results.Count);
            Assert.AreEqual(6, results[0].Quantity);
            Assert.AreEqual(1, results[1].Quantity);
        }

        /// <summary>
        /// Проверяем, можно ли удалить запись из корзины
        /// </summary>
        [TestMethod]
        public void Can_Remove_Line()
        {
            // Arrange
            Game game = new Game { GameId = 3, Name = "Game3" };
            cart.AddItem(game, 2);

            // Action
            cart.RemoveLine(game);

            // Assert
            Assert.AreEqual(0, cart.Lines.Count(c => c.Game == game));
            Assert.AreEqual(2, cart.Lines.Count());
        }

        /// <summary>
        /// Проверяем, правильно ли рассчитывается итоговая сумма заказа
        /// </summary>
        [TestMethod]
        public void Calculate_Cart_Total()
        {
            // Arrange
            cart.AddItem(gamesList[0], 5);

            // Action
            decimal result = cart.ComputeTotalValue();

            // Assert
            Assert.AreEqual(655, result);
        }

        /// <summary>
        /// Проверяем возможность очистки корзины
        /// </summary>
        [TestMethod]
        public void Can_Clear_Contents()
        {
            // Action
            cart.Clear();

            // Assert
            Assert.AreEqual(0, cart.Lines.Count());
        }

        /// <summary>
        /// Проверяем добавление в корзину
        /// </summary>
        [TestMethod]
        public void Can_Add_To_Cart()
        {
            // Arrange
            CartController controller = new CartController(gameRepoMock.Object, null);

            // Action
            controller.AddToCart(cart, 3, null);

            // Assert
            Assert.AreEqual(3, cart.Lines.Count());
            Assert.AreEqual(3, cart.Lines.ToList()[2].Game.GameId);
        }

        /// <summary>
        /// Проверяем, работает ли перенаправление на страницу корзины после добавления туда товара
        /// </summary>
        [TestMethod]
        public void Adding_Game_Ti_Cart_Goes_To_Cart_Screen()
        {
            // Arrange
            CartController controller = new CartController(gameRepoMock.Object, null);

            // Action
            RedirectToRouteResult result = controller.AddToCart(cart, 3, "myUrl");

            // Assert
            Assert.AreEqual("Index", result.RouteValues["action"]);
            Assert.AreEqual("myUrl", result.RouteValues["returnUrl"]);
        }

        /// <summary>
        /// Проверяем ссылку
        /// </summary>
        [TestMethod]
        public void Can_View_Cart_Contents()
        {
            // Arrange
            CartController target = new CartController(null, null);

            //Action
            CartIndexViewModel result = (CartIndexViewModel)target.Index(cart, "myUrl").ViewData.Model;

            //Assert
            Assert.AreSame(cart, result.Cart);
            Assert.AreEqual("myUrl", result.ReturnUrl);
        }

        /// <summary>
        /// Проверяем возможность заказа товара из пустой корзины
        /// </summary>
        [TestMethod]
        public void Cannot_Checkout_Empty_Cart()
        {
            // Arrange
            cart.Clear();
            ShippingDetails shippingDetails = new ShippingDetails();
            CartController controller = new CartController(null, orderProcMock.Object);

            // Action
            ViewResult result = controller.Checkout(cart, shippingDetails);

            // Assert
            orderProcMock.Verify(m => m.ProcessOrder(It.IsAny<Cart>(), It.IsAny<ShippingDetails>()),
                Times.Never());
            Assert.AreEqual(string.Empty, result.ViewName);
            Assert.IsFalse(result.ViewData.ModelState.IsValid);
        }

        /// <summary>
        /// Проверяем невозможность выполнения кода при ошибке в ShippingDetails
        /// </summary>
        [TestMethod]
        public void Cannot_Checkout_Invalid_ShippingDetails()
        {
            // Arrange
            CartController controller = new CartController(null, orderProcMock.Object);
            controller.ModelState.AddModelError("error", "error");

            // Action
            ViewResult result = controller.Checkout(cart, new ShippingDetails());

            // Assert
            orderProcMock.Verify(m => m.ProcessOrder(It.IsAny<Cart>(), It.IsAny<ShippingDetails>()),
                Times.Never());
            Assert.AreEqual(string.Empty, result.ViewName);
            Assert.IsFalse(result.ViewData.ModelState.IsValid);
        }

        [TestMethod]
        public void Can_Checkout_And_Submit_Order()
        {
            // Arrange
            CartController controller = new CartController(null, orderProcMock.Object);

            // Action
            ViewResult result = controller.Checkout(cart, new ShippingDetails());

            // Assert
            orderProcMock.Verify(m => m.ProcessOrder(It.IsAny<Cart>(), It.IsAny<ShippingDetails>()),
                Times.Once());
            Assert.AreEqual("Completed", result.ViewName);
            Assert.IsTrue(result.ViewData.ModelState.IsValid);
        }
    }
}
