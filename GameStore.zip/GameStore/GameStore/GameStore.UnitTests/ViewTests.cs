﻿using GameStore.Domain.Abstract;
using GameStore.Domain.Entities;
using GameStore.WebUI.Controllers;
using GameStore.WebUI.HtmlHelpers;
using GameStore.WebUI.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace GameStore.UnitTests
{
    [TestClass]
    public class ViewTests
    {
        private readonly Mock<IGameRepository> gameRepoMock;
        private readonly GameController gameController;
        private readonly NavController navController;

        public ViewTests()
        {
            // Arrange (Подготовка)
            gameRepoMock = new Mock<IGameRepository>();
            gameRepoMock.Setup(m => m.Games).Returns(new List<Game>
            {
                new Game { GameId = 1, Name = "Игра1", Category = "Cat1"},
                new Game { GameId = 2, Name = "Игра2", Category = "Cat2"},
                new Game { GameId = 3, Name = "Игра3", Category = "Cat1"},
                new Game { GameId = 4, Name = "Игра4", Category = "Cat2"},
                new Game { GameId = 5, Name = "Игра5", Category = "Cat3"}
            });
            gameController = new GameController(gameRepoMock.Object);
            gameController.pageSize = 3;
            navController = new NavController(gameRepoMock.Object);
        }

        [TestMethod]
        public void Can_Paginate()
        {
            // Действие (act)
            GamesListViewModel result = (GamesListViewModel)gameController
                .List(null, 2).Model;

            // Утверждение (assert)
            List<Game> games = result.Games.ToList();
            Assert.IsTrue(games.Count == 2);
            Assert.AreEqual("Игра4", games[0].Name);
            Assert.AreEqual("Игра5", games[1].Name);
        }

        [TestMethod]
        public void Can_Generate_Page_Links()
        {
            // Организация - определение вспомогательного метода HTML - это необходимо
            // для применения расширяющего метода
            HtmlHelper myHelper = null;

            // Организация - создание объекта PagingInfo
            PagingInfo pagingInfo = new PagingInfo
            {
                CurrentPage = 2,
                TotalItems = 28,
                ItemsPerPage = 10
            };

            // Организация - настройка делегата с помощью лямбда-выражения
            Func<int, string> pageUrlDelegate = i => "Page" + i;

            // Действие
            MvcHtmlString result = myHelper.PageLinks(pagingInfo, pageUrlDelegate);

            // assert
            Assert.AreEqual(@"<a class=""btn btn-default"" href=""Page1"">1</a>"
                + @"<a class=""btn btn-default btn-primary selected"" href=""Page2"">2</a>"
                + @"<a class=""btn btn-default"" href=""Page3"">3</a>",
                result.ToString());
        }

        [TestMethod]
        public void Can_Send_Pagination_View_Model()
        {
            // Act
            GamesListViewModel result
                = (GamesListViewModel)gameController.List(null,2).Model;

            // Assert
            PagingInfo pageInfo = result.PagingInfo;
            Assert.AreEqual(2, pageInfo.CurrentPage);
            Assert.AreEqual(3, pageInfo.ItemsPerPage);
            Assert.AreEqual(5, pageInfo.TotalItems);
            Assert.AreEqual(2, pageInfo.TotalPages);
        }

        [TestMethod]
        public void Can_Filter_Games()
        {
            // Action
            List<Game> result = ((GamesListViewModel)gameController
                .List("Cat2", 1).Model).Games
                .ToList();

            // Assert
            Assert.AreEqual(2, result.Count);
            Assert.IsTrue(result[0].Name == "Игра2"
                && result[0].Category == "Cat2");
            Assert.IsTrue(result[1].Name == "Игра4"
                && result[1].Category == "Cat2");
        }

        [TestMethod]
        public void Can_Create_Categories()
        {
            // Action
            List<string> result = ((IEnumerable<string>)navController
                .Menu().Model)
                .ToList();

            // Assert
            Assert.AreEqual(3, result.Count);
            Assert.AreEqual("Cat1", result[0]);
            Assert.AreEqual("Cat2", result[1]);
            Assert.AreEqual("Cat3", result[2]);
        }

        [TestMethod]
        public void Indicates_Selected_Category()
        {
            // Arrange
            string categoryToSelect = "Cat2";

            // Action
            string result = navController
                .Menu(categoryToSelect)
                .ViewBag.SelectedCategory;

            // Assert
            Assert.AreEqual(categoryToSelect, result);
        }

        [TestMethod]
        public void Generate_Category_Specific_Game_Count()
        {
            // Action
            int res1 = ((GamesListViewModel)gameController.List("Cat1").Model)
                .PagingInfo.TotalItems;
            int res2 = ((GamesListViewModel)gameController.List("Cat2").Model)
                .PagingInfo.TotalItems;
            int res3 = ((GamesListViewModel)gameController.List("Cat3").Model)
                .PagingInfo.TotalItems;
            int resAll = ((GamesListViewModel)gameController.List(null).Model)
                .PagingInfo.TotalItems;

            // Assert
            Assert.AreEqual(2, res1);
            Assert.AreEqual(2, res2);
            Assert.AreEqual(1, res3);
            Assert.AreEqual(5, resAll);
        }
    }
}
